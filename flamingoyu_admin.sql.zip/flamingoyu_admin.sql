-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июл 04 2021 г., 09:54
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `flamingoyu_admin`
--

-- --------------------------------------------------------

--
-- Структура таблицы `about_page`
--
-- Создание: Июн 11 2021 г., 22:53
-- Последнее обновление: Июн 11 2021 г., 22:55
--

DROP TABLE IF EXISTS `about_page`;
CREATE TABLE `about_page` (
  `id` int(11) UNSIGNED NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `about_page`
--

INSERT INTO `about_page` (`id`, `content`) VALUES
(1, '<p>Мы хотим, чтобы наши покупательницы по всему миру носили нашу одежду с таким же удовольствием, с каким мы ее производим.</p>\r\n\r\n<p>Flamingo − это международное предприятие, работающее в сфере моды, с центральным офисом в Гамбурге. Мы подхватываем новейшие модные тренды и воплощаем их в эффектные модели одежды всевозможных стилей и размеров на все случаи жизни. Пять собственных брендов и ежемесячные новые коллекции − вот отличная причина, чтобы заглянуть в наш интернет-магазин, полистать наш каталог или посетить один из наших филиалов в Германии.</p>\r\n\r\n<p>Концепция успеха: Flamingo входит в топ-десятку интернет-магазинов с самым высоким оборотом (по результатам исследования «Цифровой коммерческий рынок Германии 2018», проведенного EHI Retail Institute / Statista). Нам сопутствует успех и на международном рынке.</p>');

-- --------------------------------------------------------

--
-- Структура таблицы `after_favorite_page`
--
-- Создание: Июн 11 2021 г., 22:53
-- Последнее обновление: Июн 11 2021 г., 22:55
--

DROP TABLE IF EXISTS `after_favorite_page`;
CREATE TABLE `after_favorite_page` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `after_favorite_page`
--

INSERT INTO `after_favorite_page` (`id`, `title`, `content`) VALUES
(1, 'Flamingo – Твой любимый магазин!', '<p>Flamingo – это российский бренд одежды, обуви и аксессуаров, это 27 лет на рынке, это более 300 магазинов в 4 странах СНГ и десятки тысяч довольных покупателей. FLAMINGO – это вещи для тебя! </p>\r\n\r\n<p>Flamingo создает изделия на собственных фабриках из высококлассного хлопка. Главный приоритет бренда – качество по доступной цене! Flamingo – бренд, пользующийся популярностью у покупателей, это бренд №1 по объемам продаж в категории «одежда» на сайтах Wildberries и Ozon.</p>\r\n\r\n<p>Каждая 5-ая девушка в России, от 16 до 24 лет, носит одежду FLAMINGO!* И это неудивительно, ведь в FLAMINGO каждый может найти себе что-то по вкусу: у нас есть и яркие худи с уникальными принтами, и классические изделия, как, например, белая футболка бренда FLAMINGO, лучшая в своем классе. Мы производим и продаем не только одежду, но и обувь и аксессуары, созданные по уникальным разработкам наших дизайнеров. А совсем недавно FLAMINGO запустил собственную линейку косметики!</p>');

-- --------------------------------------------------------

--
-- Структура таблицы `company_page`
--
-- Создание: Июн 11 2021 г., 22:53
-- Последнее обновление: Июн 22 2021 г., 12:47
--

DROP TABLE IF EXISTS `company_page`;
CREATE TABLE `company_page` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `company_page`
--

INSERT INTO `company_page` (`id`, `title`, `content`) VALUES
(1, 'Мы считаем, что поиск идеальных моделей одежды не должен занимать много времени!', 'Мы в Flamingo любим жизнь во всех ее проявлениях. Суматошные будни или волнующие моменты праздников − мы знаем все пожелания наших покупательниц, и не в последнюю очередь из личного опыта. Ведь сотрудницы Flamingo также многогранны и индивидуальны, как и все женщины этой планеты. И мы уверены: человек, который чувствует себя уверенно и привлекательно, именно так и выглядит. Менеджер вася');

-- --------------------------------------------------------

--
-- Структура таблицы `contacts_page`
--
-- Создание: Июн 11 2021 г., 22:53
-- Последнее обновление: Июн 12 2021 г., 20:46
--

DROP TABLE IF EXISTS `contacts_page`;
CREATE TABLE `contacts_page` (
  `id` int(11) UNSIGNED NOT NULL,
  `oblast` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `contacts_page`
--

INSERT INTO `contacts_page` (`id`, `oblast`, `name`, `phone`, `time`) VALUES
(1, 'Ростовская область', 'Flamingo | Газетный 31/68', '+7 (905) 495-17-21', '10:00 - 22:00');

-- --------------------------------------------------------

--
-- Структура таблицы `instagramm_page`
--
-- Создание: Июн 11 2021 г., 22:53
-- Последнее обновление: Июн 11 2021 г., 22:53
--

DROP TABLE IF EXISTS `instagramm_page`;
CREATE TABLE `instagramm_page` (
  `id` int(11) UNSIGNED NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `instagramm_page`
--

INSERT INTO `instagramm_page` (`id`, `img`) VALUES
(1, 'befcd8868606a817b3215ef99dd91c3e.png'),
(2, 'c5b5c20fbc2d3984b3086fcb2a7f9f69.png'),
(3, '183f0e517b35f20d24aa8cd3bea52853.png'),
(4, '43a78d7c085e9ee58d44c74865d52027.png');

-- --------------------------------------------------------

--
-- Структура таблицы `items_page`
--
-- Создание: Июн 11 2021 г., 22:53
-- Последнее обновление: Июн 11 2021 г., 22:53
--

DROP TABLE IF EXISTS `items_page`;
CREATE TABLE `items_page` (
  `id` int(11) UNSIGNED NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `items_page`
--

INSERT INTO `items_page` (`id`, `img`) VALUES
(1, 'c5db54a869a8d9a33e373f135c1571bd.png'),
(2, 'b120c81a0ab9cf952f9efb00dd75238f.png'),
(3, '6072e027916a0c2cea17f1f6f4408eda.png'),
(4, '12ff3b8f0dbf9e221e240847756fec35.png');

-- --------------------------------------------------------

--
-- Структура таблицы `offer_page`
--
-- Создание: Июн 11 2021 г., 22:53
-- Последнее обновление: Июн 20 2021 г., 21:29
--

DROP TABLE IF EXISTS `offer_page`;
CREATE TABLE `offer_page` (
  `id` int(11) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `offer_page`
--

INSERT INTO `offer_page` (`id`, `title`, `content`) VALUES
(1, 'Сайт-Визитка ', 'FLAMINGO предоставляет скидку 15% держателям карт Flamingo Classic, Flamingo Gold, Flamingo Platinum, Flamingo Signature и Flamingo Infinite. ');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `about_page`
--
ALTER TABLE `about_page`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `after_favorite_page`
--
ALTER TABLE `after_favorite_page`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `company_page`
--
ALTER TABLE `company_page`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `contacts_page`
--
ALTER TABLE `contacts_page`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `instagramm_page`
--
ALTER TABLE `instagramm_page`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `items_page`
--
ALTER TABLE `items_page`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `offer_page`
--
ALTER TABLE `offer_page`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `about_page`
--
ALTER TABLE `about_page`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `after_favorite_page`
--
ALTER TABLE `after_favorite_page`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `company_page`
--
ALTER TABLE `company_page`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `contacts_page`
--
ALTER TABLE `contacts_page`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `instagramm_page`
--
ALTER TABLE `instagramm_page`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `items_page`
--
ALTER TABLE `items_page`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `offer_page`
--
ALTER TABLE `offer_page`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
